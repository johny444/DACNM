#include "DanangStatistics.h" 
#include <iostream>
using std::cerr;
using std::endl;


Define_Module(DanangStatistics)

void DanangStatistics::initialize(int stage) {
	if (stage == 0) {
	allBeaconsReceivedSignal = registerSignal("allBeaconsReceivedSignal"); 
	allNewWarningsReceivedSignal = registerSignal("allNewWarningsReceivedSignal");
	allWarningsReceivedSignal = registerSignal("allWarningsReceivedSignal");
	allMessagesReceivedSignal = registerSignal("allMessagesReceivedSignal"); 
	allBeaconsReceived = allWarningsReceived = newWarningsReceived = allMessagesReceived = 0;
	numAccidentsOccurred = 0;
	} 
}
void DanangStatistics::finish() {}
void DanangStatistics::updateAllBeaconsReceived() 
{
	++allBeaconsReceived;
	emit(allBeaconsReceivedSignal, allBeaconsReceived); 
}
void DanangStatistics::updateNewWarningsReceived() 
{ 
	++newWarningsReceived;
	emit(allNewWarningsReceivedSignal, newWarningsReceived);
	// cerr << "num warnings: " << newWarningsReceived << simTime().str() << endl; 
}
void DanangStatistics::updateAllWarningsReceived()
{
	emit(allWarningsReceivedSignal, ++allWarningsReceived);
}
void DanangStatistics::updateAllMessagesReceived() 
{
	emit(allMessagesReceivedSignal, ++allMessagesReceived); 
}
void DanangStatistics::incrementAccidentOccurred() 
{
	emit(numAccidentsSignal, ++numAccidentsOccurred); 
}
