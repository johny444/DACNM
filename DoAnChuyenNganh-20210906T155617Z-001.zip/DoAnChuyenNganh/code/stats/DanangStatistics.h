#ifndef DANANGSTATISTICS_H 
#define DANANGSTATISTICS_H 
#include <csimplemodule.h>
class DanangStatistics : public cSimpleModule 
{
	public:
		void updateAllBeaconsReceived(); 
		void updateNewWarningsReceived(); 
		void updateAllWarningsReceived();
		void updateAllMessagesReceived();
		int getNumberOfAccidentsOccurred() { return numAccidentsOccurred; }
		void incrementAccidentOccurred();
	protected:
		int allBeaconsReceived;
		int newWarningsReceived; 
		int allWarningsReceived;
		int allMessagesReceived; 
		int numAccidentsOccurred;
		simsignal_t allBeaconsReceivedSignal; 
		simsignal_t allNewWarningsReceivedSignal;
		simsignal_t allWarningsReceivedSignal;
		simsignal_t allMessagesReceivedSignal; 
		simsignal_t numAccidentsSignal;
	protected:
	virtual void initialize(int stage); 
	virtual void finish();
};
class DanangStatisticsAccess {
	public: 
		DanangStatisticsAccess() { }
		DanangStatistics* getIfExists() {
			return dynamic_cast<DanangStatistics*>(simulation.getModuleByPath("stats"));
		} 
};
#endif // DANANGSTATISTICS_H
