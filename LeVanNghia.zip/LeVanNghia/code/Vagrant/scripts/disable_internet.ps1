# Purpose: remove internet access so malware can't reach out to the internet
# Disable-NetAdapter -Name "Ethernet 3" -Confirm:$False
