function ValidateIPaddress(ipaddress) {
    var ipformat = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (ipaddress=='any' || ipaddress=="") return true;
    if (ipaddress.match(ipformat)) return true;
    return false;
}
function ValidatePort(port) {
    if (port=="any" || port=="") return true;
    if (!(/^[1-9]\d*$/.test(port) && 1 <= 1 * port && 1 * port <= 65535)) return false
    return true;
}
function ValidateSID(num) {
    if (!(/^[1-9]\d*$/.test(num) && 1000000 <= 1 * num && 1 * num <= 999999999)) return false
    return true;
}
function ValidateRange(num) {
    if (!(/^[1-9]\d*$/.test(num) && 1 <= 1 * num && 1 * num <= 999999999)) return false
    return true;
}
function ValidateOffset(offset) {
    return Number.isInteger(1 * offset);
}
function ValidateDepth(num) {
    if (!(/^[1-9]\d*$/.test(num) && 1 <= 1 * num && 1 * num <= 65535)) return false
    return true;
}
function ValidateString(s) {
    var a = s.split(' ');
    if (a.length>1) return false;
    return true;
}
function FormatContent(content) {
    var s = content+'';
    s=s.replace(/\"/g,'|22|');
    s=s.replace(/\'/g,'|27|');
    s=s.replace(/\;/g,'|3b|');
    s=s.replace(/\:/g,'|3a|');
    s=s.replace(/\\/g,'|5c|');
    s=s.split('||').join(' ');
    return s;
}
function fun() {
    var rule = "alert ";
    var protocol = document.getElementById("protocol").value;
    var sip = document.getElementById("sip").value;
    if (!ValidateIPaddress(sip)) {
        sip="";
        document.getElementById("sip").value="Invalid";
    }
    var sport = document.getElementById("sport").value;
    if (!ValidatePort(sport)) {
        sport="";
        document.getElementById("sport").value="Invalid";
    }
    var dip = document.getElementById("dip").value;
    if (!ValidateIPaddress(dip)) {
        dip="";
        document.getElementById("dip").value="Invalid";
    }
    var dport = document.getElementById("dport").value;
    if (!ValidatePort(dport)) {
        dport="";
        document.getElementById("dport").value="Invalid";
    }
    rule = rule+protocol+" "+sip+" "+sport+" "+document.getElementById("direction").value+" "+dip+" "+dport;
    var option = "";
    var msg = document.getElementById("msg").value.replace(/\"/g,"'");;
    if (msg!="") option += 'msg:"'+msg+'"; ';
    var content = document.getElementById("content").value;
    if (content!="") {
        if (document.getElementById("not").checked) option += 'content:!"';
            else option += 'content:"';
        content = FormatContent(content);
        option += content+'"; ';
        var offset = document.getElementById("offset").value;
        if (offset!="") 
            if (ValidateOffset(offset)) option += 'offset:'+offset+'; ';
                else document.getElementById("offset").value="Invalid";
        var depth = document.getElementById("depth").value;
        if (depth!="") 
            if (ValidateDepth(depth)) option += 'depth:'+depth+'; ';
                else document.getElementById("depth").value="Invalid";
        if (document.getElementById("nocase").checked) option+='nocase; ';
        if (document.getElementById("uri").checked) option+='http_uri; ';
    }
    var classtype = document.getElementById("classtype").value;
    ValidateString(classtype);
    if (classtype!="") 
        if (ValidateString(classtype)) option+='classtype:'+classtype+'; ';
            else document.getElementById("classtype").value="Invalid";
    var pri = document.getElementById("pri").value;
    if (pri!="") option+='priority:'+pri+'; ';
    var sid = document.getElementById("sid").value;
    if (sid!="") 
        if (ValidateSID(sid)) option += 'sid:'+sid+'; ';
            else document.getElementById("sid").value="Invalid";
    var rev = document.getElementById("rev").value;
    if (rev!="") 
        if (ValidateRange(rev)) option += 'rev:'+rev+'; ';
            else document.getElementById("rev").value="Invalid";
    if (option!="") rule = rule+" ( "+option+")";
    document.getElementById("view").value = rule;
}
function save() {
    var copyText = document.getElementById("view");
    copyText.select();
    document.execCommand("copy");
    alert("Copied the text: " + copyText.value);
}